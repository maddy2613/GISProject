import arcpy
from arcgis.gis import GIS
import json

from arcgis.features import FeatureLayer
from arcgis.mapping import WebMap

 

# Connect to your GIS (ArcGIS Online or ArcGIS Enterprise)

gis = GIS("home")
web_map_item = gis.content.get("dc46a21f5508477a93f5492bfd9d9003")
web_map = WebMap(web_map_item)
operational_layer = web_map.layers[0]
print(operational_layer)
popup_info = {
    "title":"Srinivas Test",
    "popupElements":[
        {
            "type":"fields",
            "fieldInfos":[
                {
                    "fieldName":"HazardType",
                    "label":"Hazard Type",
                    "visible":True
                },
{
                    "fieldName":"Description",
                    "label":"Hazard Type Desc",
                    "visible":True
                }

            ]
        }
    ]
}
operational_layer.popupInfo =popup_info
web_map.update()
print("popup attributes updated successfully.")
exit(0)

 



item = gis.content.get("e1d7dd5f4d2f4e2b87f437f5c7b717c6")
item_data = item.get_data()
field_infos = item_data['operationalLayers'][0]['popupInfo']['fieldInfos']
for field in field_infos:
    field["visible"] = False

item_properties = {"text": json.dumps(item_data)}
item.update(item_properties=item_properties)
exit(0)

# URL to the feature service with attachments

old_mapping_object ={}
new_mapping_object = {}
old_feature_service = 'https://services8.arcgis.com/QXU1wnp8jR3hzYxa/arcgis/rest/services/srta_production_fc/FeatureServer/0'
old_feature_layer = FeatureLayer(old_feature_service)
old_features = old_feature_layer.query(where="objectid  in (1,2,3,4,5,6,7,8,9,10)", return_geometry=False)
for feature in old_features:
    #replace OBJECTID with globalid and RefNumber with Unique DW_Audit filed
    if  feature.attributes['Refnumber'] is not None:
        old_mapping_object[feature.attributes['OBJECTID']] = feature.attributes['Refnumber']
print("globalId is mapped with Unique Number successfully")

# Get New Feature ObjectIds
new_feature_service = 'https://services8.arcgis.com/QXU1wnp8jR3hzYxa/arcgis/rest/services/srta_production_fc/FeatureServer/0'
new_feature_layer = FeatureLayer(new_feature_service)
new_features = new_feature_layer.query(where="objectid  in (1,2,3,4,5,6,7,8,9,10)", return_geometry=False)
for feature in new_features:
    #replace OBJECTID with globalid and RefNumber with Unique DW_Audit filed
    if feature.attributes['Refnumber'] is not None:
        new_mapping_object[feature.attributes['Refnumber']] = feature.attributes['OBJECTID']
print("unique Id with Objectid is mapped successfully")

# downloding attachments from FeatureClass
feature_service_url = 'https://services8.arcgis.com/QXU1wnp8jR3hzYxa/arcgis/rest/services/srta_production_fc/FeatureServer/0'
# Create a feature layer

feature_layer = FeatureLayer(feature_service_url)
# Query the features
features = feature_layer.query(where="objectid  in (1,2,3,4,5,6,7,8,9,10)", return_geometry=False)

 

# Loop through features and retrieve attachments

dic_parent = {}

for feature in features:
    # Get the attachments for each feature
    attachments = feature_layer.attachments.get_list(feature.attributes['OBJECTID'])
    #print(feature.attributes['globalid'])
    #print(attachments)
    # Loop through attachments
    att_obj = []
    for attachment in attachments:
        attachment_info = feature_layer.attachments.download(oid=feature.attributes['OBJECTID'], attachment_id=attachment['id'])
        att_obj.append(attachment_info[0])
        #print(attachment_info)

    #print(feature)
    unique_Id = old_mapping_object[feature.attributes['OBJECTID']]
    dic_parent[unique_Id] = att_obj


print('attachment mapping object is prepared successfully')
# print(dic_parent)
attach_feature_service = 'https://services8.arcgis.com/QXU1wnp8jR3hzYxa/arcgis/rest/services/srta_production_fc/FeatureServer/0'
attach_feature_layer = FeatureLayer(attach_feature_service)
for key in dic_parent:
    try:
        # add Attchments
        try:
            obj_id = new_mapping_object[key]
            for att_path in dic_parent[key]:
                try:
                    # attachment_path = r"C:\\Users\\srvclu\\AppData\\Local\\Temp\\3\\logo.png"
                    token = gis._con._token
                    # object_id = 4
                    attach_feature_layer.attachments.add(oid=obj_id, file_path=att_path)
                except Exception as err2:
                    print(err2)
                    continue
        except Exception as err1:
            print("{} key not found".format(key))
            continue
    except Exception as err:
        print(err)