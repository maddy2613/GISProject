import xml.etree.ElementTree as Et

tree = Et.parse(r'C:\SRV\downloadattachments\config.xml')
root = tree.getroot()
file_path =r'C:\SRV\downloadattachments\popupconfig.txt'
def read_webmap_layer_fields():
    try:
        webmpas = []
        with open(file_path,"r") as file:
            index=0
            web_map_url = ""
            map = {
                'itemId': '',
                'layers': {}
            }
            for line in file:
                print(line)
                if index == 0:
                    map['itemId'] = line.strip()
                    index = index + 1
                    continue
                if index == 1:
                    map['layers'][line.strip()]={"fields":[]}
                    web_map_url = line.strip()
                    index = index + 1
                    continue
                if not line.__contains__("**"):
                    map['layers'][web_map_url]['fields'].append({'aliyas': line.strip()})
                else:
                    exist_map = [obj for obj in webmpas if obj['itemId'] == map['itemId']]
                    if len(exist_map) == 0:
                        webmpas.append(map)
                    index = 1
                    continue
                index = index+1
            print(webmpas)
            return webmpas
    except Exception as err:
        print(err)

def get_fields_mappings_by_webmap_layers():
    webmpas = []
    for webmap in root.iter('webMap'):
        if webmap.attrib['sync'] == 'true':
            map = {'name': webmap.attrib['name'],
                   'itemId': webmap.attrib['itemId'],
                   'layers': {}
                   }
            index = 0
            for layer in webmap.iter('layer'):
                map['layers'][layer.attrib['url']] = {
                    'url': layer.attrib['url'],
                    'name': layer.attrib['name'],
                    'popupTitle': layer.attrib['popupTitle'],
                    'fields': []
                }
                for filed in layer.iter('field'):
                    map['layers'][layer.attrib['url']]['fields'].append({
                        'name': filed.attrib['name'],
                        'aliyas': filed.attrib['aliyas'],
                        'order': filed.attrib['order'],
                    })
                index = index+1
            webmpas.append(map)
            if len(webmpas):
                return webmpas


def get_portal_info():
    portal_url = root.find('portalUrl')
    portal_username = root.find('portalusername')
    portal_password = root.find('portalpassword')
    log_path = root.find('logpath')
    return portal_url.text, portal_username.text, portal_password.text, log_path.text





