import logging
import  configReader
import datetime
from arcgis.gis import GIS
import  requests
import  arcpy
import json
from arcgis.features import FeatureLayer
from arcgis.mapping import WebMap

portal_url, portal_user, portal_password, log_path = configReader.get_portal_info()

logger = logging.getLogger("LoggerName")
log_format = "%(asctime)s - %(levelname)s - %(message)s"
log_level = logging.INFO
filename = log_path + datetime.datetime.now().strftime('%Y_%m_%d.log')
logging.basicConfig(filename=filename, format=log_format,
                    level=log_level)
def update_webmaps_layer_popups():
    try:
        logger.info('process started..!!!')
        gis = GIS("home")

        webmaps = configReader.get_fields_mappings_by_webmap_layers()
        token = gis._con.token
        # logger.info(webmaps)
        for map in webmaps:
            try:
                web_map_item = gis.content.get(map['itemId'])
                web_map = WebMap(web_map_item)
                # print(web_map)
                for operation_layer in web_map.layers:
                    try:
                        layer_obj = map['layers'][operation_layer.url]
                        try:
                            layerObjRest = requests.get('{0}?token={1}&f=pjson'.format(operation_layer.url, token))
                            if layerObjRest.status_code == 200:
                                layer_fields = [obj['name'] for obj in layerObjRest.json()['fields']]
                                fileds_info = []
                                for l_fields in layer_obj['fields']:
                                    if l_fields['name'] in layer_fields:
                                        fileds_info.append({
                                            "fieldName": l_fields['name'],
                                            "label": l_fields['aliyas'],
                                            "visible": True
                                        })
                                    else:
                                        logger.info('Field name is not exist in the layer, field name is {}'.format(l_fields['name']))
                                popup_info = {
                                    "title": layer_obj['popupTitle'],
                                    "popupElements": [
                                        {
                                            "type": "fields",
                                            "fieldInfos": fileds_info
                                        }
                                    ]
                                }
                                operation_layer.popupInfo = popup_info
                                web_map.update()
                        except Exception as err1:
                            continue
                        print(layer_obj)
                    except Exception as err:
                        continue
                logger.info('web map popup info updated successfully.. Item Id id {}'.format(map['itemId']))
            except Exception as err3:
                logger.error('error occurd while updating popup info {}'.format(err3))
                continue
    except Exception as err_m:
        logger.error(err_m)


update_webmaps_layer_popups()