import xml.etree.ElementTree as Et

tree = Et.parse(r'C:\SRV\downloadattachments\config.xml')
root = tree.getroot()


def get_fields_mappings_by_webmap_layers():
    webmpas = []
    for webmap in root.iter('webMap'):
        if webmap.attrib['sync'] == 'true':
            map = {'name': webmap.attrib['name'],
                   'itemId': webmap.attrib['itemId'],
                   'layers': {}
                   }
            index = 0
            for layer in webmap.iter('layer'):
                map['layers'][layer.attrib['url']] = {
                    'url': layer.attrib['url'],
                    'name': layer.attrib['name'],
                    'popupTitle': layer.attrib['popupTitle'],
                    'fields': []
                }
                for filed in layer.iter('field'):
                    map['layers'][layer.attrib['url']]['fields'].append({
                        'name': filed.attrib['name'],
                        'aliyas': filed.attrib['aliyas'],
                        'order': filed.attrib['order'],
                    })
                index = index+1
            webmpas.append(map)
            if len(webmpas):
                return webmpas


def get_portal_info():
    portal_url = root.find('portalUrl')
    portal_username = root.find('portalusername')
    portal_password = root.find('portalpassword')
    log_path = root.find('logpath')
    return portal_url.text, portal_username.text, portal_password.text, log_path.text





