"""
Create an Audit
"""
from os.path import join, dirname, basename
from copy import copy
from secrets import choice
from typing import List
from time import time

import arcpy

OBJECT_ID_FIELD = 'OBJECTID'
LENGTH_FIELD = 'zzlengthzz'
AUDIT_LOCATION_ID = 'AUDIT_TOOL_LOCATION_ID'
TEMP_FC_NAME = 'audit_locations'
TO_MILES_DIV = 1609.34
arcpy.env.overwriteOutput = True


def select_random_feature(feature_class: str) -> str:
    """
    Select Random Feature and return feature layer with one selected

    Args:
        feature_class:

    Returns:

    """
    with arcpy.da.SearchCursor(feature_class, [OBJECT_ID_FIELD]) as cursor:
        ids = [row[0] for row in cursor]
    selected = choice(ids)
    lyr_name = f'selection_layer_{int(time())}'
    arcpy.AddMessage(lyr_name)
    arcpy.MakeFeatureLayer_management(feature_class, lyr_name)
    arcpy.SelectLayerByAttribute_management(
        lyr_name, 'NEW_SELECTION', f'"{OBJECT_ID_FIELD}" = {selected}')
    return lyr_name
# End select_random_feature function


def find_current_length(feature_layer) -> float:
    """
    Find the current length

    Args:
        feature_layer:

    Returns:

    """
    with arcpy.da.SearchCursor(feature_layer, [LENGTH_FIELD]) as cursor:
        selected_length = sum([row[0] for row in cursor])
    return selected_length
# End find_current_length functino


def select_touching_to_distance(
        feature_layer: str, distance_per_site: float) -> float:
    """
    Select touching to distance

    Args:
        feature_layer:
        distance_per_site:

    Returns:

    """
    total_selected_distance = 0
    last_selected_distance = 0
    delta_distance = 1
    counter = 0
    while total_selected_distance < distance_per_site and delta_distance > 0:
        arcpy.SelectLayerByLocation_management(
            feature_layer, 'BOUNDARY_TOUCHES', feature_layer, None,
            'ADD_TO_SELECTION')
        total_selected_distance = find_current_length(feature_layer)
        delta_distance = total_selected_distance - last_selected_distance
        last_selected_distance = total_selected_distance
        counter += 1
        if counter > 50:
            break
    return total_selected_distance
# End select_touching_to_distance function


def copy_selected_to_output(feature_layer: str, output_feature_class: str,
                            site_id: int, field_list: List[str]):
    """
    Copy selected to output

    Args:
        feature_layer:
        output_feature_class:
        site_id:
        field_list

    Returns:

    """
    ins_field_list = copy(field_list)
    ins_field_list.append(AUDIT_LOCATION_ID)
    with arcpy.da.InsertCursor(
            output_feature_class, ins_field_list) as insert_cursor:
        with arcpy.da.SearchCursor(feature_layer, field_list) as cursor:
            for row in cursor:
                row = list(row)
                row.append(site_id)
                insert_cursor.insertRow(row)
    arcpy.DeleteFeatures_management(feature_layer)
# End copy_selected_to_output function


def create_temp_copy(feature_layer: str) -> str:
    """
    Create Temp Copy of input

    Args:
        feature_layer: feature class or feature layer given by user

    Returns:

    """
    arcpy.AddMessage('Creating a working copy...')
    temp_gdb = 'IN_MEMORY'
    arcpy.CopyFeatures_management(feature_layer, join(temp_gdb, TEMP_FC_NAME))
    fc = join(temp_gdb, TEMP_FC_NAME)
    arcpy.AddField_management(fc, AUDIT_LOCATION_ID, 'LONG')
    arcpy.AddField_management(fc, LENGTH_FIELD, 'DOUBLE')
    try:
        arcpy.CalculateGeometryAttributes_management(
            fc, [[LENGTH_FIELD, 'LENGTH']], 'METERS')
    except RuntimeError as err:
        if "ERROR 000800" in str(err):
            arcpy.CalculateGeometryAttributes_management(
                fc, [[LENGTH_FIELD, 'LENGTH_GEODESIC']], 'METERS')
    return fc
# End create_temp_copy


def create_output_feature_class(
        temp_feature_class: str, output_feature_class: str):
    """
    Create the output feature class

    Args:
        temp_feature_class:
        output_feature_class:

    Returns:

    """
    arcpy.AddMessage('Creating output datasets...')
    props = arcpy.Describe(temp_feature_class)
    arcpy.CreateFeatureclass_management(
        dirname(output_feature_class), basename(output_feature_class),
        'POLYLINE', temp_feature_class, None, None, props.spatialReference)
# End create_output_feature_class function


def generate_summary_table(
        audits_feature_class: str, output_summary_table: str):
    """
    Output Summary table

    Args:
        audits_feature_class:
        output_summary_table:

    Returns:

    """
    arcpy.Statistics_analysis(
        audits_feature_class,
        output_summary_table, [[LENGTH_FIELD, 'SUM']], AUDIT_LOCATION_ID)
# End generate_summary_table function


def generate_locations(temp_fc: str, distance_per_site_m: float,
                       total_distance_m: float, output_feature_class: str):
    """
    Generate Location

    Args:
        temp_fc:
        distance_per_site_m:
        total_distance_m:
        output_feature_class:

    Returns:

    """
    total_accumulated_distance = 0
    location_counter = 1
    field_list = [f.name for f in arcpy.ListFields(temp_fc)
                  if f.type != 'Geometry']
    field_list.append("SHAPE@")
    arcpy.AddMessage('Generating locations...')
    while total_accumulated_distance < total_distance_m:
        arcpy.AddMessage(f'generating Location {location_counter}')
        selection = select_random_feature(temp_fc)
        loc_dist = select_touching_to_distance(selection, distance_per_site_m)
        copy_selected_to_output(
            selection, output_feature_class, location_counter, field_list)
        arcpy.AddMessage(f'..{loc_dist:.1f} meters '
                         f'or {loc_dist/TO_MILES_DIV:.3f} miles')
        location_counter += 1
        total_accumulated_distance += loc_dist
        arcpy.AddMessage(
            f'..Accumulation: {total_accumulated_distance:.1f} meters '
            f'or {total_accumulated_distance / TO_MILES_DIV:.3f} miles')
        # TODO - handle exit if we never get enough distance
# Emd generate_locations fucntion


def create_audit(feature_layer: str, distance_per_site: float,
                 total_distance: float, output_feature_class: str,
                 output_summary_table: str):
    """
    Create Audit entry point.  Distances to be given in meters.

    Args:
        feature_layer:
        distance_per_site:
        total_distance:
        output_feature_class:
        output_summary_table:

    Returns:

    """
    distance_per_site = float(distance_per_site) * TO_MILES_DIV
    total_distance = float(total_distance) * TO_MILES_DIV
    temp_fc = create_temp_copy(feature_layer)
    create_output_feature_class(temp_fc, output_feature_class)
    generate_locations(temp_fc, distance_per_site, total_distance,
                       output_feature_class)
    generate_summary_table(output_feature_class, output_summary_table)
# End create_audit function


if __name__ == '__main__':
    create_audit(r'C:\Users\n2w1\OneDrive - PGE\Documents\ArcGIS\Projects\VegSampling\VegSampling.gdb\OH_SI_1_Project',
                 0.5, 25,
                 r'C:\Users\n2w1\OneDrive - PGE\Documents\ArcGIS\Projects\VegSampling\VegSampling.gdb\TEST_SELECTION',
                 r'C:\Users\n2w1\OneDrive - PGE\Documents\ArcGIS\Projects\VegSampling\VegSampling.gdb\TEST_SELECTION_SUMMARY')
