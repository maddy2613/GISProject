import pyodbc
from arcgis.gis import GIS
from arcgis.features import FeatureLayer
import logging
import datetime

import xml.etree.ElementTree as Et


tree = Et.parse(r'F:\srv\appendDatatoFC\config.xml')
root = tree.getroot()
dbconnection = root.find('sqlconnection').text
viewcommand = root.find('sqlView').text
server = root.find('server').text
database = root.find('database').text
username = root.find('username').text
password = root.find('password').text
log_path = root.find('log_path').text

logger = logging.getLogger("LoggerName")
log_format = "%(asctime)s - %(levelname)s - %(message)s"
log_level = logging.INFO
filename = log_path + datetime.datetime.now().strftime('%Y_%m_%d.log')
logging.basicConfig(filename=filename, format=log_format,
                    level=log_level)

gis = GIS("home")
logger.info('connected to Portal')
feature_layer = gis.content.get("2d4b0c9e19234905a157abee1cf6aae1")
feature_layer = feature_layer.layers[0]

import pandas as pd
import pyodbc
import arcpy

# Define the connection parameters
# server = '10.93.209.78'
# database = 'gisdb'
# username = 'zhouser'
# password = 'Zho@Admin6789*'
insert_fields = ["ArabicName","FacilityNameInEnglish","City","Latitude","Longitude","PhoneNumber"]

# Establish the connection
conn = pyodbc.connect('DRIVER={SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)

# Execute the query and fetch the results into a pandas DataFrame
data = pd.read_sql(viewcommand, conn)

# Close the connection
conn.close()
logger.info('successfully read data from sql View')

feature_attributes=[];
for index,row in data.iterrows():
    feature_obj = {}
    point_geometry = {}
    spatial_reference = arcpy.SpatialReference(4326)
    for col in insert_fields:
        feature_obj[col] = row[col]
        if col == 'Longitude':
            point_geometry["Y"] = row[col]
            continue
        if col == 'Latitude':
            point_geometry["X"] = row[col]
            continue
    feature = {"attributes": feature_obj,
              "geometry": {"x":point_geometry["X"],"y":point_geometry["Y"]}
              }
    feature_attributes.append(feature)
print(feature_attributes)
logger.info(feature_attributes)
add_results = feature_layer.edit_features(adds = feature_attributes)
print(add_results)
logger.info(add_results)
count = 0
for obj in add_results['addResults']:
    if obj['success'] :
        count = count+1
print('{} successfully inserted features'.format(count))
logger.info('{} successfully inserted features'.format(count))

